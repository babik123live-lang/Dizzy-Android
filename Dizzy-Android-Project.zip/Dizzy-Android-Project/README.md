# Dizzy Android

Android wrapper for the user-provided NES ROM **Fantastic Adventures of Dizzy**.

## What is included

- the supplied NES ROM under `app/src/main/assets/game.nes`
- landscape fullscreen Android app
- responsive layout for phone/tablet
- touch D-pad + A/B + Start/Select
- original NES audio through JSNES
- save/load state from the in-game menu
- GitHub Actions workflow that builds an installable debug APK

## Build on GitHub

The workflow `.github/workflows/build-apk.yml` runs automatically after push to `main` and can also be started manually from **Actions → Build Dizzy Android APK → Run workflow**.

After a successful run, open the run and download artifact **Dizzy-Android-APK**. The APK inside is `app-debug.apk`.

## Important

This project contains the ROM supplied by the user. Do not publish or redistribute it unless you have the rights to do so. Use a private repository for personal builds.

## Technical notes

The workflow downloads JSNES 2.0.0 during build and copies `dist/jsnes.min.js` into Android assets before Gradle runs. This keeps the project ZIP smaller and makes the emulator dependency reproducible.
